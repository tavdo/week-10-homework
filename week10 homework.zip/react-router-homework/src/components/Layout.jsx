import { NavLink, Outlet } from 'react-router-dom'

export default function Layout() {
  return (
    <div style={{ maxWidth: 880, margin: '0 auto', padding: '1rem' }}>
      <header style={{ display: 'flex', gap: '1rem', alignItems: 'center', padding: '0.5rem 0' }}>
        <nav style={{ display: 'flex', gap: '1rem' }}>
          <NavLink to='/' end className={({ isActive }) => isActive ? 'active' : ''}>Home</NavLink>
          <NavLink to='/about' className={({ isActive }) => isActive ? 'active' : ''}>About</NavLink>
          <NavLink to='/contact' className={({ isActive }) => isActive ? 'active' : ''}>Contact</NavLink>
        </nav>
      </header>
      <hr />
      <main style={{ padding: '1rem 0' }}>
        <Outlet />
      </main>
      <footer style={{ marginTop: '2rem', fontSize: 12, opacity: 0.7 }}>
        React Router Homework
      </footer>
    </div>
  )
}