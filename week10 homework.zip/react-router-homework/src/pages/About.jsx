import { useSearchParams, Link } from 'react-router-dom'

export default function About() {
  const [searchParams] = useSearchParams()
  const topic = searchParams.get('topic')

  return (
    <div>
      <h1>About Page</h1>
      <p>This is a demo project for learning React Router.</p>

      <p>Try topics:</p>
      <ul>
        <li><Link to='/about?topic=history'>About — History</Link></li>
        <li><Link to='/about?topic=features'>About — Features</Link></li>
      </ul>

      {topic && <p><strong>Currently viewing topic:</strong> {topic}</p>}
    </div>
  )
}