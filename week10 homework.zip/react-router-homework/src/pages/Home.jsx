import { Link } from 'react-router-dom'

const users = ['Alex', 'Sarah', 'Taylor', 'Jordan']

export default function Home() {
  return (
    <div>
      <h1>Welcome to Home Page</h1>
      <p>Navigate through the app:</p>

      <h3>Static Links</h3>
      <ul>
        <li><Link to='/about'>Go to About</Link></li>
        <li><Link to='/contact?ref=homepage'>Contact (from Homepage)</Link></li>
        <li><Link to='/contact?ref=newsletter'>Contact (from Newsletter)</Link></li>
        <li><Link to='/user/Alex'>User: Alex</Link></li>
        <li><Link to='/user/Sarah'>User: Sarah</Link></li>
      </ul>

      <h3>Dynamic User List</h3>
      <ul>
        {users.map(u => (
          <li key={u}><Link to={`/user/${u}`}>{u}</Link></li>
        ))}
      </ul>
    </div>
  )
}