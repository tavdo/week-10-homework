import { useParams, useNavigate } from 'react-router-dom'

export default function User() {
  const { username } = useParams()
  const navigate = useNavigate()

  return (
    <div>
      <h1>User Page</h1>
      <p>Welcome, <strong>{username}</strong>!</p>
      <button onClick={() => navigate(-1)}>Go Back</button>
    </div>
  )
}