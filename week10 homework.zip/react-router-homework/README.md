# React Session 10 – Homework: React Router & Multi-Page Navigation

This small multi-page React app demonstrates routing concepts, dynamic routes, query parameters, and programmatic navigation using **React Router v6**.

## ✨ Features
- Home, About, Contact, User routes
- Dynamic routing with `useParams()` (`/user/:username`)
- Query parameters with `useSearchParams()` (`/contact?ref=homepage`)
- Programmatic navigation with `useNavigate()`
- Nested routes under a shared `Layout` with `<Outlet />`
- 404 page for undefined routes
- Active link highlighting via `NavLink`

## 🚀 Getting Started
```bash
npm install
npm run dev
```

## 🧭 Useful URLs
- `/user/Alex` and `/user/Sarah`
- `/contact?ref=homepage`
- `/about?topic=history`